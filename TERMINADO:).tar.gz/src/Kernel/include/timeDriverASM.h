#ifndef TIMEDriverASM_h
#define TIMEDriverASM_h

int _getHour();
int _getMinute();
int _getSecond();

#endif