/* 
	****** 	Module for Sound 	******
*/

#ifndef SOUNDMODULE_H
#define SOUNDMODULE_H

// Turns beep sound on
void doBeep();

// Turns beep sound off
void noBeep();

#endif