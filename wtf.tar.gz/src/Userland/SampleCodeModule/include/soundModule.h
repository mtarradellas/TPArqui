#ifndef SOUNDMODULE_H
#define SOUNDMODULE_H

void beep();
void noBeep();

#endif