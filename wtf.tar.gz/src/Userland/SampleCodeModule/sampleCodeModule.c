#include <shell.h>



int main() {
	initShell();
	return 0;
}